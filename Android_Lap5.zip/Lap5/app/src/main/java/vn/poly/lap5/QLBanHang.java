package vn.poly.lap5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

public class QLBanHang extends AppCompatActivity {
    private TextView tvInfo;
    private EditText edtImId;
    private QLBanHangSQlite qlBanHangSQlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qlban_hang);
        tvInfo = findViewById(R.id.tvInfo);
        edtImId = findViewById(R.id.edtImId);
        qlBanHangSQlite = new QLBanHangSQlite(QLBanHang.this);
    }

    public void InsertOK(View view) {
        Product newPR = new Product("PH" + new Random().nextInt(), "Nguyễn Thành Nam", R.drawable.img1, 10);

        long result = qlBanHangSQlite.insert(newPR);
        if (result < 0) {
            Toast.makeText(this, "khong thanh cong", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "thanh cong", Toast.LENGTH_SHORT).show();
        }
        select();
    }

    public void UpdateOK(View view) {
        List<Product> productList = qlBanHangSQlite.getAll();
        for (int i = 0; i < productList.size(); i++) {
            if (edtImId.getText().toString().equals(productList.get(i).getId())) {

                Product newPR = new Product("PH1", "Nam Thành Nguyễn", R.drawable.img1, 20);
                long result = qlBanHangSQlite.update(newPR);
                if (result < 0) {
                    Toast.makeText(this, "khong thanh cong", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "thanh cong", Toast.LENGTH_SHORT).show();
                }
                select();
            }else{
                tvInfo.setText("");
            }
        }
    }

    public void DeleteOK(View view) {
        int del = qlBanHangSQlite.delete("PH1");
        if (del < 0) {
            Toast.makeText(this, "khong thanh cong", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "thanh cong", Toast.LENGTH_SHORT).show();
        }
        select();
    }

    public void SeeAll(View view) {
        List<Product> productList = qlBanHangSQlite.getAll();
        String id = "", name = "", price = "";
        for (int i = 0; i < productList.size(); i++) {
            id = id + "" + productList.get(i).getId() + "\n";
            name = name + "" + productList.get(i).getName() + "\n";
            price = price + "" + productList.get(i).getPrice() + "\n";
        }
        tvInfo.setText(id + "," + name + "," + price);
    }

    public void select() {
        List<Product> productList = qlBanHangSQlite.getAll();
        String id = "", name = "", price = "";
        for (int i = 0; i < productList.size(); i++) {
            id = id + "" + productList.get(i).getId() + "\n";
            name = name + "" + productList.get(i).getName() + "\n";
            price = price + "" + productList.get(i).getPrice() + "\n";
        }
        tvInfo.setText(id + "," + name + "," + price);
    }
}
