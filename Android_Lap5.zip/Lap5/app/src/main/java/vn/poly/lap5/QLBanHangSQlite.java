package vn.poly.lap5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class QLBanHangSQlite extends SQLiteOpenHelper {
    public QLBanHangSQlite(Context context) {
        super(context, "lap5sql.db", null, 1);
    }

    String CREATE_QuanLiBH = "CREATE TABLE QuanLiBH ( id VARCHAR PRIMARY KEY,name VARCHAR,image INTEGER,price DOUBLE) ";

    private final String T_NAME = "QuanLiBH";
    private final String C_ID = "id";
    private final String C_NAME = "name";
    private final String C_IM = "image";
    private final String C_PRICE = "price";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QuanLiBH);
    }

    public long insert(Product product) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        //ghep cap gtr
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, product.getId());
        contentValues.put(C_NAME, product.getName());
        contentValues.put(C_IM, product.getImage());
        contentValues.put(C_PRICE, product.getPrice());

        //insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);

        //dong ket noi
        sqLiteDatabase.close();

        return result;
    }

    public long update(Product product) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        //ghep cap gtr
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, product.getId());
        contentValues.put(C_NAME, product.getName());
        contentValues.put(C_IM, product.getImage());
        contentValues.put(C_PRICE, product.getPrice());

        //insert
        long result = sqLiteDatabase.update(T_NAME, contentValues, C_ID + "=?", new String[]{product.getId()});

        //dong ket noi
        sqLiteDatabase.close();

        return result;
    }

    public int delete(String id) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        //
        return sqLiteDatabase.delete(T_NAME, C_ID + "=?", new String[]{id});
    }

    public List<Product> getAll() {
        List<Product> products = new ArrayList<>();
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();

        //b2:khai bao cau lenh select
        String SELECT = "SELECT * FROM " + T_NAME;

        //b3:viet lenh truy van
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Product product = new Product(cursor.getString(0), cursor.getString(1), cursor.getInt(2), cursor.getDouble(3));
                products.add(product);
            } while (cursor.moveToNext());

            //b4:dong ket noi
            sqLiteDatabase.close();
        }
        return products;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
