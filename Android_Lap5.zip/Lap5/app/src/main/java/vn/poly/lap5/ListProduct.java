package vn.poly.lap5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ListProduct extends AppCompatActivity {
    private ListView lvList;
    private List<Product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sinh_vien);
        lvList = findViewById(R.id.lvList);

        productList = new ArrayList<>();//luc nao cung can
        for (int i = 0; i <10 ; i++) {
            Product newSV = new Product("PH"+(i+1),"Nguyễn Thành Nam",R.drawable.img1,10);
            productList.add(newSV);
        }
        ProductAdapter productAdapter = new ProductAdapter(ListProduct.this,productList);
        lvList.setAdapter(productAdapter);

    }
}
