package vn.poly.assignment.SQlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StudentReaderSQL extends SQLiteOpenHelper {

    public static final String CREATE_TABLE =
            "CREATE TABLE Student (Name VARCHAR,Bth NVARCHAR)";

    public static final String T_NAME = "Student";
    public static final String C_NAME = "Name";
    public static final String C_BTHDAY = "Bth";

    public StudentReaderSQL(Context context) {
        super(context, "Student.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
