package vn.poly.assignment.model;

public class Student {
    private String Name, Bth;

    public Student() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getBth() {
        return Bth;
    }

    public void setBth(String bth) {
        Bth = bth;
    }
}
