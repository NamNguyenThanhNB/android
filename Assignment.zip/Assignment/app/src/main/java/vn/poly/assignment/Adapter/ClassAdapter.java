package vn.poly.assignment.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import vn.poly.assignment.R;
import vn.poly.assignment.model.ClassSV;

public class ClassAdapter extends BaseAdapter {
    int i = 0;
    private Context context;
    private List<ClassSV> svList;

    public ClassAdapter(Context context, List<ClassSV> svList) {
        this.context = context;
        this.svList = svList;
    }

    @Override
    public int getCount() {
        return svList.size();
    }

    @Override
    public Object getItem(int position) {
        return svList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.row, parent, false);

            viewHolder.tvSTT = convertView.findViewById(R.id.tvSTT);
            viewHolder.tvML = convertView.findViewById(R.id.tvML);
            viewHolder.tvTL = convertView.findViewById(R.id.tvTL);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.tvSTT.setText(position+1 + "");
        viewHolder.tvML.setText(svList.get(position).getMaL());
        viewHolder.tvTL.setText(svList.get(position).getTenL());

        return convertView;
    }

    private class ViewHolder {
        TextView tvSTT, tvML, tvTL;
    }
}
