package vn.poly.assignment.model;

public class ClassSV {
    private String MaL, tenL;

    public ClassSV() {
    }

    public ClassSV(String maL, String tenL) {
        MaL = maL;
        this.tenL = tenL;
    }

    public String getMaL() {
        return MaL;
    }

    public void setMaL(String maL) {
        MaL = maL;
    }

    public String getTenL() {
        return tenL;
    }

    public void setTenL(String tenL) {
        this.tenL = tenL;
    }
}
