package vn.poly.assignment.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import vn.poly.assignment.R;
import vn.poly.assignment.model.ClassSV;
import vn.poly.assignment.model.Student;

public class StudentAdapter extends BaseAdapter {
    int i = 0;
    private Context context;
    private List<Student> students;

    public StudentAdapter(Context context, List<Student> students) {
        this.context = context;
        this.students = students;
    }

    @Override
    public int getCount() {
        return students.size();
    }

    @Override
    public Object getItem(int position) {
        return students.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.row, parent, false);

            viewHolder.tvSTT = convertView.findViewById(R.id.tvSTT);
            viewHolder.tvML = convertView.findViewById(R.id.tvML);
            viewHolder.tvTL = convertView.findViewById(R.id.tvTL);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.tvSTT.setText(position+1 + "");
        viewHolder.tvML.setText(students.get(position).getName());
        viewHolder.tvTL.setText(students.get(position).getBth());

        return convertView;
    }

    private class ViewHolder {
        TextView tvSTT, tvML, tvTL;
    }
}
