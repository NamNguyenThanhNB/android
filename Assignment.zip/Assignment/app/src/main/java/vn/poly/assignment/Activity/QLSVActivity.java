package vn.poly.assignment.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatSpinner;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import vn.poly.assignment.Adapter.ClassAdapter;
import vn.poly.assignment.Adapter.MySpinnerAdapter;
import vn.poly.assignment.Adapter.StudentAdapter;
import vn.poly.assignment.R;
import vn.poly.assignment.SQlite.ClassDAO;
import vn.poly.assignment.SQlite.StudentDAO;
import vn.poly.assignment.SQlite.StudentReaderSQL;
import vn.poly.assignment.model.ClassSV;
import vn.poly.assignment.model.Student;

public class QLSVActivity extends AppCompatActivity {
    private Button btnInsertSV;
    private ListView lvQLSVList;
    private EditText edtQLSVTenSV, edtQLSVBthSV;
    private StudentDAO studentDAO;
    private StudentAdapter studentAdapter;
    private SimpleDateFormat sdf;
    private AppCompatSpinner spPart;
    private ClassDAO classDAO;


    List<Student> studentList;
    List<ClassSV> classSVList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qlsv);
        lvQLSVList = findViewById(R.id.lvQLSVList);
        btnInsertSV = findViewById(R.id.btnInsertSV);
        edtQLSVTenSV = findViewById(R.id.edtQLSVTenSV);
        edtQLSVBthSV = findViewById(R.id.edtQLSVBthSV);

        studentDAO = new StudentDAO(this);
        studentList = studentDAO.getAllStudent();

        classDAO = new ClassDAO(QLSVActivity.this);
        classSVList = classDAO.getAllClassSV();
        sdf = new SimpleDateFormat();


        //lam viec voi Spinner
        final List<ClassSV> list = new ArrayList<>();
        spPart = findViewById(R.id.spPart);


        // tao ra 1 doi tuong empty de hien thi mac dinh cho spinner

        ClassSV classSV = new ClassSV();
        classSV.setTenL("Select One");
        list.add(classSV);

        for (int i = 1; i < classSVList.size(); i++) {
            classSV.setTenL(classSVList.get(i).getTenL());
            list.add(classSV);
        }

        MySpinnerAdapter mySpinnerAdapter = new MySpinnerAdapter(QLSVActivity.this, list);
        spPart.setAdapter(mySpinnerAdapter);


        // su kien chon 1 hang trong spinner
        spPart.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            // nguoi dung click va chon 1 hang trong danh sach
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ClassSV classSV = list.get(position);
                Toast.makeText(QLSVActivity.this, classSV.getTenL(), Toast.LENGTH_SHORT).show();

            }


            // neu nguoi dung mo spinner ma ko chon gi
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        //hien thi len list
        final List<Student> students = new ArrayList<>();
        for (int i = 0; i < studentList.size(); i++) {
            Student sv = new Student();
            sv.setName(studentList.get(i).getName());
            sv.setBth(studentList.get(i).getBth());
            students.add(sv);
        }

        studentAdapter = new StudentAdapter(QLSVActivity.this, students);
        lvQLSVList.setAdapter(studentAdapter);

        //xoa thong tin tren list
        lvQLSVList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String getName = students.get(position).getName();
                int result = studentDAO.delStudent(getName);
                if (result > 0) {
                    Toast.makeText(QLSVActivity.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                    return false;
                } else {
                    Toast.makeText(QLSVActivity.this, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
    }

    public void insertSv(View view) {
        String name = edtQLSVTenSV.getText().toString();
        String bth = edtQLSVBthSV.getText().toString();
        if (name.equals("")) {
            Toast.makeText(QLSVActivity.this, "Tên sinh viên không được để trống", Toast.LENGTH_SHORT).show();
            edtQLSVTenSV.requestFocus();
            return;
        }

        if ((bth.equals(""))) {
            Toast.makeText(QLSVActivity.this, "Ngày sinh của sinh viên không để trống", Toast.LENGTH_SHORT).show();
            edtQLSVBthSV.requestFocus();
            return;
        } else if (!(bth.equals(""))) {
            try {
                sdf.applyPattern("dd-mm-yyyy");
                Date date = (Date) sdf.parse(String.valueOf(edtQLSVBthSV.getText()));
                if (!(name.equals(""))) {
                    Student student = new Student();
                    student.setName(name);
                    student.setBth(bth);
                    long result = studentDAO.insertStudent(student);
                    if (result < 0) {
                        Toast.makeText(QLSVActivity.this, "Thêm thông tin không thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(QLSVActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (Exception e) {
                Toast.makeText(QLSVActivity.this, "Ngày sinh của sinh viên không hợp lệ", Toast.LENGTH_SHORT).show();
            }
        }
    }
}



