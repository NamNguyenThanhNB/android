package vn.poly.assignment.Adapter;

import android.content.Context;
import android.database.DataSetObserver;
import android.support.v7.widget.AppCompatSpinner;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import java.util.List;

import vn.poly.assignment.R;
import vn.poly.assignment.model.ClassSV;

public class MySpinnerAdapter implements SpinnerAdapter {
    private Context context;
    private List<ClassSV> clList;


    public MySpinnerAdapter(Context context, List<ClassSV> clList) {
        this.context = context;
        this.clList = clList;
    }


    // giao dien cho hang khi hien thi spinner
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {

        convertView = LayoutInflater.from(context).inflate(R.layout.myspinner, parent, false);

        TextView tvInfo;

        tvInfo = convertView.findViewById(R.id.tvInfo);

        tvInfo.setText(clList.get(position).getTenL());

        return convertView;

    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getCount() {
        return clList.size();
    }

    @Override
    public ClassSV getItem(int position) {
        return clList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }


    // giao dien cho hang duoc chon
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(R.layout.myspinner, parent, false);

        TextView tvInfo;

        tvInfo = convertView.findViewById(R.id.tvInfo);

        tvInfo.setText(clList.get(position).getTenL());

        tvInfo.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));

        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
