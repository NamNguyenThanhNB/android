package vn.poly.assignment.Activity;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import vn.poly.assignment.Adapter.ClassAdapter;
import vn.poly.assignment.R;
import vn.poly.assignment.SQlite.ClassDAO;
import vn.poly.assignment.model.ClassSV;

public class SeeAllClassActivity extends AppCompatActivity {
    private ClassDAO classDAO;
    private ListView lvLView;
    private AlertDialog alertDialog, alertDialog2;
    boolean a = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all_class);
        lvLView = findViewById(R.id.lvLView);
        classDAO = new ClassDAO(SeeAllClassActivity.this);


        final List<ClassSV> lvList = new ArrayList<>();
        final List<ClassSV> classSVList = classDAO.getAllClassSV();

        if (classSVList.size() < 1) {
            final AlertDialog.Builder bur = new AlertDialog.Builder(this);//khoi tao lam viec voi dialog

            View alt = LayoutInflater.from(this).inflate(R.layout.mesage, null);
            bur.setView(alt);
            final Button btnYES, btnNO;

            btnYES = alt.findViewById(R.id.btnYES);
            btnNO = alt.findViewById(R.id.btnNO);

            btnYES.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(SeeAllClassActivity.this);//khoi tao lam viec voi dialog

                    View alert = LayoutInflater.from(SeeAllClassActivity.this).inflate(R.layout.mydialog, null);

                    builder.setView(alert);

                    final EditText edtMaL, edtTenL;
                    final Button btnClearC, btnSaveC;

                    edtMaL = alert.findViewById(R.id.edtMaL);
                    edtTenL = alert.findViewById(R.id.edtTenL);
                    btnClearC = alert.findViewById(R.id.btnClearC);
                    btnSaveC = alert.findViewById(R.id.btnSaveC);


                    btnClearC.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            edtMaL.setText("");
                            edtTenL.setText("");
                        }
                    });

                    btnSaveC.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String mal = edtMaL.getText().toString();
                            String tenl = edtTenL.getText().toString();
                            if (mal.equals("")) {
                                Toast.makeText(SeeAllClassActivity.this, "Mã lớp không được để trống", Toast.LENGTH_SHORT).show();
                                edtMaL.requestFocus();
                                return;
                            } else if ((tenl.equals(""))) {
                                Toast.makeText(SeeAllClassActivity.this, "Tên lớp không để trống", Toast.LENGTH_SHORT).show();
                                edtMaL.requestFocus();
                                return;
                            } else {
                                ClassSV classSV = new ClassSV();
                                classSV.setMaL(mal);
                                classSV.setTenL(tenl);
                                long result = classDAO.insertClass(classSV);
                                if (result < 0) {
                                    Toast.makeText(SeeAllClassActivity.this, "lưu lớp không thành công", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(SeeAllClassActivity.this, "lưu lớp thành công", Toast.LENGTH_SHORT).show();
                                    a = true;
                                    alertDialog.dismiss();
                                    lvList.add(classSV);
                                    ClassAdapter classAdapter = new ClassAdapter(SeeAllClassActivity.this, lvList);
                                    lvLView.setAdapter(classAdapter);
                                }
                            }
                            if (a == true) {
                                alertDialog2.dismiss();
                            }
                        }
                    });


                    builder.create();//hien thi le man hinh
                    alertDialog = builder.show();
                }
            });

            btnNO.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    System.exit(0);
                }
            });
            bur.create();
            alertDialog2 = bur.show();//hien thi le man hinh

        } else {
            for (int i = 0; i < classSVList.size(); i++) {
                ClassSV classSV = new ClassSV();
                classSV.setMaL(classSVList.get(i).getMaL());
                classSV.setTenL(classSVList.get(i).getTenL());
                lvList.add(classSV);
            }

            ClassAdapter classAdapter = new ClassAdapter(SeeAllClassActivity.this, lvList);
            lvLView.setAdapter(classAdapter);
            lvLView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    String getID = lvList.get(position).getMaL();
                    int result = classDAO.delClass(getID);
                    if (result > 0) {
                        Toast.makeText(SeeAllClassActivity.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                        return false;
                    } else {
                        Toast.makeText(SeeAllClassActivity.this, "Xóa không thành công", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                }
            });
        }


    }
}
