package vn.poly.assignment.Activity;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import vn.poly.assignment.R;
import vn.poly.assignment.SQlite.ClassDAO;
import vn.poly.assignment.model.ClassSV;


public class MainActivity extends AppCompatActivity {
    private Button btnInsertClass, btnSeeAllClass, btnQLSV;
    private ClassDAO classDAO;
    private AlertDialog alertDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        classDAO = new ClassDAO(MainActivity.this);

    }

    public void insertClass(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//khoi tao lam viec voi dialog

        View alert = LayoutInflater.from(this).inflate(R.layout.mydialog, null);

        builder.setView(alert);

        final EditText edtMaL, edtTenL;
        final Button btnClearC, btnSaveC;

        edtMaL = alert.findViewById(R.id.edtMaL);
        edtTenL = alert.findViewById(R.id.edtTenL);
        btnClearC = alert.findViewById(R.id.btnClearC);
        btnSaveC = alert.findViewById(R.id.btnSaveC);


        btnClearC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtMaL.setText("");
                edtTenL.setText("");
            }
        });

        btnSaveC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mal = edtMaL.getText().toString();
                String tenl = edtTenL.getText().toString();
                if (mal.equals("")) {
                    Toast.makeText(MainActivity.this, "Mã lớp không được để trống", Toast.LENGTH_SHORT).show();
                    edtMaL.requestFocus();
                    return;
                } else if ((tenl.equals(""))) {
                    Toast.makeText(MainActivity.this, "Tên lớp không để trống", Toast.LENGTH_SHORT).show();
                    edtMaL.requestFocus();
                    return;
                } else {
                    ClassSV classSV = new ClassSV();
                    classSV.setMaL(mal);
                    classSV.setTenL(tenl);
                    long result = classDAO.insertClass(classSV);
                    if (result < 0) {
                        Toast.makeText(MainActivity.this, "Lưu lớp không thành công", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Lưu lớp thành công", Toast.LENGTH_SHORT).show();
                    }
                    alertDialog.dismiss();
                }
            }
        });


        builder.create();//hien thi le man hinh
        alertDialog = builder.show();
    }

    public void seeAllClass(View view) {

        Intent intent = new Intent(MainActivity.this, SeeAllClassActivity.class);
        startActivity(intent);
    }

    public void qlsv(View view) {

        Intent intent = new Intent(MainActivity.this, QLSVActivity.class);
        startActivity(intent);
    }
}
