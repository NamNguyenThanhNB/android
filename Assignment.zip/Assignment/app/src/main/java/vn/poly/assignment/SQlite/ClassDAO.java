package vn.poly.assignment.SQlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import vn.poly.assignment.model.ClassSV;

import static vn.poly.assignment.SQlite.ClassReaderSQL.C_MAL;
import static vn.poly.assignment.SQlite.ClassReaderSQL.C_TENL;
import static vn.poly.assignment.SQlite.ClassReaderSQL.T_NAME;

public class ClassDAO {
    private ClassReaderSQL classReaderSQL;

    public ClassDAO(Context context) {

        classReaderSQL = new ClassReaderSQL(context);

    }

    public long insertClass(ClassSV classSV) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = classReaderSQL.getWritableDatabase();

        //Cursor
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_MAL, classSV.getMaL());
        contentValues.put(C_TENL, classSV.getTenL());

        //insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);
        //dong kn
        sqLiteDatabase.close();

        return result;
    }

    public long updateClass(ClassSV classSV) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = classReaderSQL.getWritableDatabase();

        //Cursor
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_MAL, classSV.getMaL());
        contentValues.put(C_TENL, classSV.getTenL());

        //update
        long result = sqLiteDatabase.update(T_NAME, contentValues, C_MAL + "=?", new String[]{classSV.getMaL()});
        //dong kn
        sqLiteDatabase.close();
        return result;
    }

    public int delClass(String maL) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = classReaderSQL.getWritableDatabase();

        int result = sqLiteDatabase.delete(T_NAME, C_MAL + "=?", new String[]{maL});
        //dong kn
        sqLiteDatabase.close();
        return result;
    }

    public List<ClassSV> getAllClassSV() {
        List<ClassSV> classSVS = new ArrayList<>();


        //xin quyen
        SQLiteDatabase sqLiteDatabase = classReaderSQL.getReadableDatabase();

        // b2 : viet cau lenh select
        String select = "SELECT * FROM " + T_NAME;


        //b3 Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(select, null);
        if (cursor.moveToFirst()) {
            do {
                ClassSV classSV = new ClassSV();
                classSV.setMaL(cursor.getString(0));
                classSV.setTenL(cursor.getString(1));
                classSVS.add(classSV);
            } while (cursor.moveToNext());

            // dong ket noi con tro
            cursor.close();


        }
        sqLiteDatabase.close();
        return classSVS;
    }
}
