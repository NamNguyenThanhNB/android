package vn.poly.assignment.SQlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.poly.assignment.model.Student;

import static vn.poly.assignment.SQlite.StudentReaderSQL.C_BTHDAY;
import static vn.poly.assignment.SQlite.StudentReaderSQL.C_NAME;
import static vn.poly.assignment.SQlite.StudentReaderSQL.T_NAME;

public class StudentDAO {
    private StudentReaderSQL studentReaderSQL;

    public StudentDAO(Context context) {

        studentReaderSQL = new StudentReaderSQL(context);

    }

    public long insertStudent(Student student) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = studentReaderSQL.getWritableDatabase();

        //Cursor
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_NAME, student.getName());
        contentValues.put(C_BTHDAY, student.getBth());

        //insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);
        //dong kn
        sqLiteDatabase.close();

        return result;
    }

    public long updateStudent(Student student) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = studentReaderSQL.getWritableDatabase();

        //Cursor
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_NAME, student.getName());
        contentValues.put(C_BTHDAY, student.getBth());


        //update
        long result = sqLiteDatabase.update(T_NAME, contentValues, C_NAME + "=?", new String[]{student.getName()});
        //dong kn
        sqLiteDatabase.close();
        return result;
    }

    public int delStudent(String name) {
        //xin quyen
        SQLiteDatabase sqLiteDatabase = studentReaderSQL.getWritableDatabase();

        int result = sqLiteDatabase.delete(T_NAME, C_NAME + "=?", new String[]{name});
        //dong kn
        sqLiteDatabase.close();
        return result;
    }

    public List<Student> getAllStudent() {
        List<Student> students = new ArrayList<>();


        //xin quyen
        SQLiteDatabase sqLiteDatabase = studentReaderSQL.getReadableDatabase();

        // b2 : viet cau lenh select
        String select = "SELECT * FROM " + T_NAME;


        //b3 Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(select, null);
        if (cursor.moveToFirst()) {
            do {
                Student student = new Student();
                student.setName(cursor.getString(0));
                student.setBth(cursor.getString(1));
                students.add(student);
            } while (cursor.moveToNext());

            // dong ket noi con tro
            cursor.close();


        }
        sqLiteDatabase.close();
        return students;
    }
}
