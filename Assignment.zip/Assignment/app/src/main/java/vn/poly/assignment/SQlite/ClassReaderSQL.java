package vn.poly.assignment.SQlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ClassReaderSQL extends SQLiteOpenHelper {

    public static final String CREATE_TABLE =
            "CREATE TABLE ClassSV (maL VARCHAR PRIMARY KEY,TenL NVARCHAR)";
//autoincrement : tự tăng
    public static final String T_NAME = "ClassSV";
    public static final String C_MAL = "maL";
    public static final String C_TENL = "TenL";

    public ClassReaderSQL(Context context) {
        super(context, "ClassSV.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
