package vn.poly.baisqlite.SQLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.StrictMode;

public class CarReadSQLite extends SQLiteOpenHelper {
    public CarReadSQLite(Context context) {
        super(context, "carSqlite.db", null, 1);
    }

    public final static String T_NAME = "carTable";
    public final static String C_ID = "id";
    public final static String C_NAME = "name";
    public final static String C_YEAR = "year";
    public final static String C_PRICE = "price";

    public final static String CREATE_TABLE = "CREATE TABLE carTable (id INTEGER PRIMARY KEY,name NVARCHAR,year INTEGER,price FLOAT)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
