package vn.poly.baisqlite.activity;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import vn.poly.baisqlite.R;
import vn.poly.baisqlite.SQLite.CarDAO;
import vn.poly.baisqlite.model.Car;

public class MainActivity extends AppCompatActivity {
    private EditText edtID, edtNAME, edtYEAR, edtPRICE;
    private CarDAO carDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtID = findViewById(R.id.edtID);
        edtNAME = findViewById(R.id.edtNAME);
        edtPRICE = findViewById(R.id.edtPRICE);
        edtYEAR = findViewById(R.id.edtYEAR);

        carDAO = new CarDAO(MainActivity.this);

    }

    public void btnInsert(View view) {
        try {
            if (edtID.getText().toString().trim().equals("")) {
                Toast.makeText(this, "ID ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtID.requestFocus();
                return;
            } else if (edtNAME.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Tên ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtNAME.requestFocus();
                return;
            } else if (edtYEAR.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Năm mua ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtYEAR.requestFocus();
                return;
            } else if (edtPRICE.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Giá ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtPRICE.requestFocus();
                return;
            } else {
                List<Car> cars = new ArrayList<>();
                Car car = new Car();
                car.id = Integer.parseInt(edtID.getText().toString().trim());
                car.name = edtNAME.getText().toString().trim();
                car.year = Integer.parseInt(edtYEAR.getText().toString().trim());
                car.price = Float.parseFloat(edtPRICE.getText().toString().trim());

                cars.add(car);


                for (int i = 0; i < cars.size(); i++) {
                    if (edtID.getText().toString().trim().equals(cars.get(i).id)) {
                        Toast.makeText(this, "ID trùng", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                if (Integer.parseInt(edtYEAR.getText().toString().trim()) < 0) {
                    Toast.makeText(this, "Năm mua không là một số âm", Toast.LENGTH_SHORT).show();
                    return;
                } else if (Float.parseFloat(edtPRICE.getText().toString().trim()) < 0) {
                    Toast.makeText(this, "Giá không là một số âm", Toast.LENGTH_SHORT).show();
                    return;
                }


                long result = carDAO.insertCar(car);
                if (result > 0) {
                    Toast.makeText(this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Thêm thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Mời ban nhập đúng thông tin : \n id:là một số nguyên. \n năm mua: là một số nguyên. \n giá mua: là một số thực.", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnUpdate(View view) {
        try {
            if (edtID.getText().toString().trim().equals("")) {
                Toast.makeText(this, "ID ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtID.requestFocus();
                return;
            } else if (edtNAME.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Tên ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtNAME.requestFocus();
                return;
            } else if (edtYEAR.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Năm mua ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtYEAR.requestFocus();
                return;
            } else if (edtPRICE.getText().toString().trim().equals("")) {
                Toast.makeText(this, "Giá ô tô đang rỗng", Toast.LENGTH_SHORT).show();
                edtPRICE.requestFocus();
                return;
            } else {
                List<Car> cars = new ArrayList<>();
                Car car = new Car();
                car.id = Integer.parseInt(edtID.getText().toString().trim());
                car.name = edtNAME.getText().toString().trim();
                car.year = Integer.parseInt(edtYEAR.getText().toString().trim());
                car.price = Float.parseFloat(edtPRICE.getText().toString().trim());

                cars.add(car);


                for (int i = 0; i < cars.size(); i++) {
                    if (edtID.getText().toString().trim().equals(cars.get(i).id)) {
                        Toast.makeText(this, "ID trùng", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                if (Integer.parseInt(edtYEAR.getText().toString().trim()) < 0) {
                    Toast.makeText(this, "Năm mua không là một số âm", Toast.LENGTH_SHORT).show();
                    return;
                } else if (Float.parseFloat(edtPRICE.getText().toString().trim()) < 0) {
                    Toast.makeText(this, "Giá không là một số âm", Toast.LENGTH_SHORT).show();
                    return;
                }


                long result = carDAO.updateCar(car);
                if (result > 0) {
                    Toast.makeText(this, "Sửa thành công", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Sửa thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "Mời ban nhập đúng thông tin : \n id:là một số nguyên. \n năm mua: là một số nguyên. \n giá mua: là một số thực.", Toast.LENGTH_SHORT).show();
        }
    }

    public void btnDelete(View view) {
        int result = carDAO.deleteCar(Integer.parseInt(edtID.getText().toString().trim()));
        if (result > 0) {
            Toast.makeText(this, "Xóa thành công", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }

    }

    public void btnGetAll(View view) {
        Intent intent = new Intent(MainActivity.this, ListCarActivity.class);
        startActivity(intent);

    }

    public void btnSortByPrice(View view) {
        Intent intent = new Intent(MainActivity.this, ListCarSortByPriceActivity.class);
        startActivity(intent);
    }

    public void btnSortByYear(View view) {
        Intent intent = new Intent(MainActivity.this, ListCarSortByYearActivity.class);
        startActivity(intent);
    }


    public void btnFind(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        final View alert = LayoutInflater.from(MainActivity.this).inflate(R.layout.mydialog, null);
        builder.setView(alert);
        alert.findViewById(R.id.btnFindID).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edtFindID;
                edtFindID = alert.findViewById(R.id.edtFindID);
                int id = Integer.parseInt(edtFindID.getText().toString().trim());
                Intent intent = new Intent(MainActivity.this, ListCarFindByIdActivity.class);

                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

        alert.findViewById(R.id.btnFindNAME).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edtFindNAME;
                edtFindNAME = alert.findViewById(R.id.edtFindNAME);
                Intent intent = new Intent(MainActivity.this, ListCarFindByNameActivity.class);
                String name = String.valueOf(edtFindNAME.getText());
                intent.putExtra("name", name);
                startActivity(intent);
            }
        });

        alert.findViewById(R.id.btnFindRANGEPRICE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edtMIN, edtMAX;
                edtMIN = alert.findViewById(R.id.edtMIN);
                edtMAX = alert.findViewById(R.id.edtMAX);
                Intent intent = new Intent(MainActivity.this, ListCarFindByRangePriceActivity.class);

                intent.putExtra("min", edtMIN.getText());
                intent.putExtra("max", edtMAX.getText());
                startActivity(intent);
            }
        });

        builder.create();
        builder.show();
    }


}
