package vn.poly.baisqlite.SQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.poly.baisqlite.model.Car;

import static vn.poly.baisqlite.SQLite.CarReadSQLite.C_ID;
import static vn.poly.baisqlite.SQLite.CarReadSQLite.C_NAME;
import static vn.poly.baisqlite.SQLite.CarReadSQLite.C_PRICE;
import static vn.poly.baisqlite.SQLite.CarReadSQLite.C_YEAR;
import static vn.poly.baisqlite.SQLite.CarReadSQLite.T_NAME;

public class CarDAO {
    private CarReadSQLite carReadSQLite;

    public CarDAO(Context context) {
        carReadSQLite = new CarReadSQLite(context);
    }

    public long insertCar(Car car) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getWritableDatabase();

        //b2:ghep cap dl voi contentValue
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, car.id);
        contentValues.put(C_NAME, car.name);
        contentValues.put(C_YEAR, car.year);
        contentValues.put(C_PRICE, car.price);

        //b3:insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);

        //b4:dong sql
        sqLiteDatabase.close();

        return result;
    }

    public long updateCar(Car car) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getWritableDatabase();

        //b2:ghep cap dl voi contentValue
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, car.id);
        contentValues.put(C_NAME, car.name);
        contentValues.put(C_YEAR, car.year);
        contentValues.put(C_PRICE, car.price);

        //b3:update
        long result = sqLiteDatabase.update(T_NAME, contentValues, C_ID + "=?", new String[]{String.valueOf(car.id)});

        //b4:dong sql
        sqLiteDatabase.close();

        return result;
    }

    public int deleteCar(int id) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getWritableDatabase();

        //b2:delete
        int result = sqLiteDatabase.delete(T_NAME, C_ID + "=?", new String[]{String.valueOf(id)});

        //b3:dong sql
        sqLiteDatabase.close();

        return result;
    }

    public List<Car> getAllCar() {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME;

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }

    public List<Car> sortByPrice() {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME + " ORDER BY " + C_PRICE + " ASC";

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }

    public List<Car> sortByYear() {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME + " ORDER BY " + C_YEAR + " ASC";

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }

    public List<Car> findById(int id) {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME + " WHERE " + C_ID + " = " + id;

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }

    public List<Car> findByName(String name) {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME + " WHERE " + C_NAME + " = " + name;

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }

    public List<Car> findByRangePrice(float min, float max) {
        List<Car> carList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = carReadSQLite.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME + " WHERE " + C_PRICE + " BETWEEN " + min + " AND " + max;

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                Car car = new Car();
                car.id = Integer.parseInt(cursor.getString(0));
                car.name = cursor.getString(1);
                car.year = Integer.parseInt(cursor.getString(2));
                car.price = Float.parseFloat(cursor.getString(3));

                carList.add(car);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return carList;
    }
}
