package vn.poly.baisqlite.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import vn.poly.baisqlite.R;
import vn.poly.baisqlite.SQLite.CarDAO;
import vn.poly.baisqlite.model.Car;

public class CarListAdapter extends BaseAdapter {
    private CarDAO carDAO;
    private Context context;
    private List<Car> carList;

    public CarListAdapter(Context context, List<Car> carList) {
        this.context = context;
        this.carList = carList;
    }

    @Override
    public int getCount() {
        return carList.size();
    }

    @Override
    public Object getItem(int position) {
        return carList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.row, null, false);

            viewHolder.tvID = convertView.findViewById(R.id.tvID);
            viewHolder.tvNAME = convertView.findViewById(R.id.tvNAME);
            viewHolder.tvYEAR = convertView.findViewById(R.id.tvYEAR);
            viewHolder.tvPRICE = convertView.findViewById(R.id.tvPRICE);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }


        viewHolder.tvID.setText(carList.get(position).id + "");
        viewHolder.tvNAME.setText(carList.get(position).name);
        viewHolder.tvYEAR.setText(carList.get(position).year + "");
        viewHolder.tvPRICE.setText(carList.get(position).price + "");

        return convertView;


    }

    private class ViewHolder {
        TextView tvID, tvNAME, tvYEAR, tvPRICE;
    }
}
