package vn.poly.baisqlite.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.List;

import vn.poly.baisqlite.R;
import vn.poly.baisqlite.SQLite.CarDAO;
import vn.poly.baisqlite.adapter.CarListAdapter;
import vn.poly.baisqlite.model.Car;

public class ListCarFindByIdActivity extends AppCompatActivity {
    private ListView lvList;
    private CarDAO carDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        lvList = findViewById(R.id.lvList);
        carDAO = new CarDAO(ListCarFindByIdActivity.this);
        int id = getIntent().getIntExtra("id", 0);
        List<Car> carList = carDAO.findById(id);

        CarListAdapter carListAdapter = new CarListAdapter(ListCarFindByIdActivity.this, carList);
        lvList.setAdapter(carListAdapter);
    }
}
