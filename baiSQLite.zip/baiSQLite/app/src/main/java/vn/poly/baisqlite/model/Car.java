package vn.poly.baisqlite.model;

public class Car {

    public int id, year;
    public String name;
    public float price;
}
