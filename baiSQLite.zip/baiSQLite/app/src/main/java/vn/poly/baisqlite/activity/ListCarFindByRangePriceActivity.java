package vn.poly.baisqlite.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.List;

import vn.poly.baisqlite.R;
import vn.poly.baisqlite.SQLite.CarDAO;
import vn.poly.baisqlite.adapter.CarListAdapter;
import vn.poly.baisqlite.model.Car;

public class ListCarFindByRangePriceActivity extends AppCompatActivity {
    private ListView lvList;
    private CarDAO carDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        lvList = findViewById(R.id.lvList);
        carDAO = new CarDAO(ListCarFindByRangePriceActivity.this);
        float min = getIntent().getFloatExtra("min", 0);
        float max = getIntent().getFloatExtra("max", 0);
        List<Car> carList = carDAO.findByRangePrice(min, max);

        CarListAdapter carListAdapter = new CarListAdapter(ListCarFindByRangePriceActivity.this, carList);
        lvList.setAdapter(carListAdapter);
    }
}
