package vn.poly.trenlop_SQlite;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private StudentReaderSQL studentReaderSQL;
    private TextView tvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInfo = findViewById(R.id.tvInfo);


        studentReaderSQL = new StudentReaderSQL(MainActivity.this);
        Student student = new Student();
        student.id = "PH" + new Random().nextInt();
        student.name = "Nam" + new Random().nextInt(1000);

        long result = studentReaderSQL.insertStudent(student);
        if (result > 0) {
            Toast.makeText(MainActivity.this, "Thành công", Toast.LENGTH_SHORT).show();
        } else {

            Toast.makeText(MainActivity.this, "Không thành công", Toast.LENGTH_SHORT).show();
        }


        List<Student> studentList = studentReaderSQL.getAllStudent();
        String id = "";
        for (int i = 0; i < studentList.size(); i++) {
            id = id + "" + studentList.get(i).id + "\n";
        }
        tvInfo.setText(id);
    }
}
