package vn.poly.trenlop_SQlite;

public class Student {
    String id,name;
}
