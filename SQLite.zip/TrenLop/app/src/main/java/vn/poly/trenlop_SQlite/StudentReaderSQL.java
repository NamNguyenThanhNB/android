package vn.poly.trenlop_SQlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class StudentReaderSQL extends SQLiteOpenHelper {


    private final String CREATE_STUDENT =
            "CREATE TABLE Student (id VARCHAR PRIMARY KEY,name VARCHAR)";

    private final String T_NAME = "Student";
    private final String C_ID = "id";
    private final String C_NAME = "name";

    public StudentReaderSQL(Context context) {
        super(context, "student.db", null, 1);
    }

    @Override//để thêm hàng thêm cột thay đổi dl
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_STUDENT);// khởi tạo bảng
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVerson, int newVersion) {

    }

    //để thêm
    public long insertStudent(Student student) {


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();


        //b2:ghep cap gtri voi ten cot
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_NAME, student.id);
        contentValues.put(C_ID, student.name);

        //b3:insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);

        //b4:dong ket noi
        sqLiteDatabase.close();
        return result;
    }


    //sửa
    public long updateStudent(Student student) {


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();


        //b2:ghep cap gtri voi ten cot
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_NAME, student.id);
        contentValues.put(C_ID, student.name);

        //b3:insert
        long result = sqLiteDatabase.update(T_NAME, contentValues, C_ID + "=?", new String[]{student.id});

        //b4:dong ket noi

        sqLiteDatabase.close();
        return result;
    }

    //xóa
    public int delStudent(String id) {

        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        //b2:xoa
        return sqLiteDatabase.delete(T_NAME, C_ID + "=?", new String[]{id});

    }


    //hiển thị sinh viên
    public List<Student> getAllStudent() {
        List<Student> students = new ArrayList<>();
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();

        //b2:khai bao cau lenh select
        String SELECT = "SELECT * FROM " + T_NAME;

        //b3:viet lenh truy van
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);

        //b4:lay du lieu tu con tro cursor(:la 1 cai mang luu dl)
        if (cursor.moveToFirst()) {

            do {
                Student student = new Student();
                student.id = cursor.getString(0);
                student.name = cursor.getString(1);
                students.add(student);
            } while (cursor.moveToNext());

            //b4:dong ket noi
            sqLiteDatabase.close();
        }
        return students;
    }


}
