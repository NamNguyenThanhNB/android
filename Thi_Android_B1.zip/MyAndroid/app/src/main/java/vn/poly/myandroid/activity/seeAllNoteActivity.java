package vn.poly.myandroid.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import vn.poly.myandroid.R;
import vn.poly.myandroid.SQLite.NoteDAO;

public class seeAllNoteActivity extends AppCompatActivity {
    private EditText edtText1, edtBody1, edtTime1;
    private String text, body, time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all_note);

        edtText1 = findViewById(R.id.edtText1);
        edtBody1 = findViewById(R.id.edtBody1);
        edtTime1 = findViewById(R.id.edtTime1);

        Bundle bundle = getIntent().getBundleExtra("data");
        text = bundle.getString("text", "");
        body = bundle.getString("body", "");
        time = bundle.getString("time", "");
        Log.e("lala: ", text + " " + body + " " + time);
        edtText1.setText(text);
        edtBody1.setText(body);
        edtTime1.setText(time);
    }

    public void saveNote(View view) {
        NoteDAO noteDAO = new NoteDAO(seeAllNoteActivity.this);
        int result = noteDAO.deleteNote(text);
        if (result > 0) {
            Toast.makeText(this, "Xoa ghi chu thanh cong", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(seeAllNoteActivity.this, MyNoteActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Xoa ghi chu khong thanh cong", Toast.LENGTH_SHORT).show();
        }
    }
}
