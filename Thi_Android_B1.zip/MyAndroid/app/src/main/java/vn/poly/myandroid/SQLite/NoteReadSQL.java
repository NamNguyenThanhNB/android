package vn.poly.myandroid.SQLite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NoteReadSQL extends SQLiteOpenHelper {
    public NoteReadSQL(Context context) {
        super(context, "notedataSQL.db", null, 1);
    }

    public final static String T_NAME = "noteTable";


    public final static String C_ID = "id";
    public final static String C_TEXT = "text";
    public final static String C_BODY = "body";
    public final static String C_TIME = "time";


    public final static String CREATE_TABLE = "CREATE TABLE noteTable(id INTEGER ,text NVARCHAR PRIMARY KEY,body NVARCHAR,time NVARCHAR)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
