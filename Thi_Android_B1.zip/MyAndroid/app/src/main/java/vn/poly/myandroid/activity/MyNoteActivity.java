package vn.poly.myandroid.activity;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

import vn.poly.myandroid.R;
import vn.poly.myandroid.SQLite.NoteDAO;
import vn.poly.myandroid.adapter.MyNoteAdapter;
import vn.poly.myandroid.model.DataNote;

public class MyNoteActivity extends AppCompatActivity {
    private ListView lvList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_note);
        lvList = findViewById(R.id.lvList);

        NoteDAO noteDAO = new NoteDAO(MyNoteActivity.this);
        final List<DataNote> dataNoteList = noteDAO.getAllOder();

        MyNoteAdapter myNoteActivity = new MyNoteAdapter(MyNoteActivity.this, dataNoteList);
        lvList.setAdapter(myNoteActivity);
        lvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = dataNoteList.get(position).text;
                String body = dataNoteList.get(position).body;
                String time = dataNoteList.get(position).time;
                Intent intent = new Intent(MyNoteActivity.this, seeAllNoteActivity.class);

                Bundle bundle = new Bundle();
                bundle.putString("text", text);
                bundle.putString("body", body);
                bundle.putString("time", time);

                intent.putExtra("data", bundle);
                startActivity(intent);
            }
        });
    }
}
