package vn.poly.myandroid.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import vn.poly.myandroid.R;
import vn.poly.myandroid.SQLite.NoteDAO;
import vn.poly.myandroid.model.DataNote;

public class AddNoteActivity extends AppCompatActivity {
    private EditText edtText, edtBody, edtTime;
    private int id = 0;
    private NoteDAO noteDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        edtText = findViewById(R.id.edtText);
        edtBody = findViewById(R.id.edtBody);
        edtTime = findViewById(R.id.edtTime);
    }

    public void saveNote(View view) {
        if (edtText.getText().equals("")) {
            Toast.makeText(this, "tieu de khong duoc de trong", Toast.LENGTH_SHORT).show();
            return;
        } else if (edtBody.getText().equals("")) {
            Toast.makeText(this, "noi dung khong duoc de trong", Toast.LENGTH_SHORT).show();
            return;
        } else if (edtTime.getText().equals("")) {
            Toast.makeText(this, "thoi gian khong duoc de trong", Toast.LENGTH_SHORT).show();
            return;
        } else {
            noteDAO = new NoteDAO(AddNoteActivity.this);
            DataNote dataNote = new DataNote();
            dataNote.id = id;
            dataNote.text = edtText.getText().toString().trim();
            dataNote.body = edtBody.getText().toString().trim();
            dataNote.time = edtTime.getText().toString().trim();
            long result = noteDAO.insertNote(dataNote);

            Log.e("ok: ", id + " " +
                    edtText.getText().toString().trim() + " " +
                    edtBody.getText().toString().trim() + " " +
                    edtTime.getText().toString().trim());
            if (result > 0) {
                Toast.makeText(this, "Them ghi chu thanh cong", Toast.LENGTH_SHORT).show();
                id++;
            } else {
                Toast.makeText(this, "Them ghi chu khong thanh cong", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
