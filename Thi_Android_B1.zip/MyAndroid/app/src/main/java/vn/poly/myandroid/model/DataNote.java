package vn.poly.myandroid.model;

public class DataNote {

    public String text, body, time;
    public int id;
}
