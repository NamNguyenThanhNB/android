package vn.poly.myandroid.SQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import vn.poly.myandroid.model.DataNote;

import static vn.poly.myandroid.SQLite.NoteReadSQL.C_BODY;
import static vn.poly.myandroid.SQLite.NoteReadSQL.C_ID;
import static vn.poly.myandroid.SQLite.NoteReadSQL.C_TEXT;
import static vn.poly.myandroid.SQLite.NoteReadSQL.C_TIME;
import static vn.poly.myandroid.SQLite.NoteReadSQL.T_NAME;

public class NoteDAO {

    private NoteReadSQL noteReadSQL;

    public NoteDAO(Context context) {
        noteReadSQL = new NoteReadSQL(context);
    }

    public long insertNote(DataNote dataNote) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = noteReadSQL.getWritableDatabase();

        //b2:ghep cap dl voi contentValue
        ContentValues contentValues = new ContentValues();
        contentValues.put(C_ID, dataNote.id);
        contentValues.put(C_TEXT, dataNote.text);
        contentValues.put(C_BODY, dataNote.body);
        contentValues.put(C_TIME, dataNote.time);

        //b3:insert
        long result = sqLiteDatabase.insert(T_NAME, null, contentValues);

        //b4:dong sql
        sqLiteDatabase.close();

        return result;
    }

    public int deleteNote(String text) {
        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = noteReadSQL.getWritableDatabase();

        //b2:delete
        int result = sqLiteDatabase.delete(T_NAME, C_TEXT + "=?", new String[]{text});

        //b3:dong sql
        sqLiteDatabase.close();

        return result;
    }

    public List<DataNote> getAllOder() {
        List<DataNote> dataOderList = new ArrayList<>();


        //b1:xin quyen
        SQLiteDatabase sqLiteDatabase = noteReadSQL.getReadableDatabase();

        //b2:select
        String SELECT = "SELECT * FROM " + T_NAME;

        //b3:lam viec voi Cursor
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT, null);
        if (cursor.moveToFirst()) {
            do {
                DataNote dataOder = new DataNote();
                dataOder.id = Integer.parseInt(cursor.getString(0));
                dataOder.text = cursor.getString(1);
                dataOder.body = (cursor.getString(2));
                dataOder.time = (cursor.getString(3));

                dataOderList.add(dataOder);
            } while (cursor.moveToNext());
        }

        //b4:dong sql
        sqLiteDatabase.close();

        return dataOderList;
    }
}
